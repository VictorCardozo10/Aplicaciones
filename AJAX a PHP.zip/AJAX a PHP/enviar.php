<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Recibir datos
    $nombre = isset($_POST['nombre']) ? $_POST['nombre'] : '';
    $edad = isset($_POST['edad']) ? $_POST['edad'] : '';

    // Validar y procesar datos
    if (!empty($nombre) && is_numeric($edad)) {
        $edad = (int)$edad;
        $respuesta = array(
            "status" => "success",
            "mensaje" => "Datos recibidos: Nombre = $nombre, Edad = $edad"
        );
    } else {
        $respuesta = array(
            "status" => "error",
            "mensaje" => "Datos inválidos"
        );
    }
    
    // Enviar respuesta como JSON
    echo json_encode($respuesta);
} else {
    http_response_code(400);
    echo json_encode(array("status" => "error", "mensaje" => "Método no permitido"));
}
?>
